/**
 * Test descriptors used within the JUnit Jupiter test engine.
 */

package org.junit.jupiter.engine.descriptor;
