/**
 * The {@link org.junit.jupiter.params.aggregator.ArgumentsAggregator} and
 * {@link org.junit.jupiter.params.aggregator.ArgumentsAccessor} interfaces and the
 * {@link org.junit.jupiter.params.aggregator.AggregateWith} annotation.
 */

package org.junit.jupiter.params.aggregator;
